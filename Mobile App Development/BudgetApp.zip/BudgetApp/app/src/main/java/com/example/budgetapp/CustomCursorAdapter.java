package com.example.budgetapp;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

public class CustomCursorAdapter extends SimpleCursorAdapter {

    private final boolean isAutoRoundEnabled;
    private final String currencySymbol;

    public CustomCursorAdapter(Context context, Cursor c, boolean isAutoRoundEnabled, String currencySymbol) {
        super(context, R.layout.list_item, c, new String[]{}, new int[]{}, 0);
        this.isAutoRoundEnabled = isAutoRoundEnabled;
        this.currencySymbol = currencySymbol;
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(context);
        return inflater.inflate(R.layout.list_item, parent, false);
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        // Get values from the cursor
        int id = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_ID));
        float budget = cursor.getFloat(cursor.getColumnIndex(DatabaseHelper.COLUMN_AMOUNT));
        float total = cursor.getFloat(cursor.getColumnIndex(DatabaseHelper.COLUMN_TOTAL));
        float expenses = cursor.getFloat(cursor.getColumnIndex(DatabaseHelper.COLUMN_EXPENSES));
        String date = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_DATE));

        // Apply auto-rounding if enabled
        if (isAutoRoundEnabled) {
            budget = Math.round(budget);
            total = Math.round(total);
            expenses = Math.round(expenses);
        }

        // Bind data to TextViews
        ((TextView) view.findViewById(R.id.tvListItemID)).setText(String.valueOf(id));
        ((TextView) view.findViewById(R.id.budget)).setText(formatCurrency(budget));
        ((TextView) view.findViewById(R.id.total)).setText(formatCurrency(total));
        ((TextView) view.findViewById(R.id.expenses)).setText(formatCurrency(expenses));
        ((TextView) view.findViewById(R.id.date)).setText(date);
    }

    // Format float values as currency with the selected symbol
    private String formatCurrency(float value) {
        return String.format("%s %.2f", currencySymbol, value);
    }
}
