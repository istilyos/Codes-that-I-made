package com.example.budgetapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;

public class SettingsActivity extends AppCompatActivity {

    private SwitchCompat switchStrictMode;
    private SharedPreferences sharedPreferences;
    private Spinner spinnerCurrency;
    private SwitchCompat switchAutoRound;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Set up toolbar and back button
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("BudgetPrefs", MODE_PRIVATE);

        // Initialize switch
        switchStrictMode = findViewById(R.id.switch_strict_mode);

        // Initialize spinner
        spinnerCurrency = findViewById(R.id.spinner_currency);

        // Load saved currency
        String savedCurrency = sharedPreferences.getString("currency", "₱ PHP");
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.currency_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCurrency.setAdapter(adapter);

        // Set selected item based on saved value
        int position = adapter.getPosition(savedCurrency);
        spinnerCurrency.setSelection(position);

        // Save selected currency
        spinnerCurrency.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedCurrency = parent.getItemAtPosition(position).toString();
                sharedPreferences.edit().putString("currency", selectedCurrency).apply();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        switchAutoRound = findViewById(R.id.switch_auto_round);
        boolean isAutoRoundEnabled = sharedPreferences.getBoolean("autoRound", false);
        switchAutoRound.setChecked(isAutoRoundEnabled);

        switchAutoRound.setOnCheckedChangeListener((buttonView, isChecked) -> {
            sharedPreferences.edit().putBoolean("autoRound", isChecked).apply();
            Toast.makeText(SettingsActivity.this, "Auto-Round: " + (isChecked ? "Enabled" : "Disabled"), Toast.LENGTH_SHORT).show();
        });

        // Load Strict Mode setting
        boolean isStrictModeEnabled = sharedPreferences.getBoolean("strictMode", true);
        switchStrictMode.setChecked(isStrictModeEnabled);

        // Toggle Strict Mode
        switchStrictMode.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                sharedPreferences.edit().putBoolean("strictMode", isChecked).apply();
                Toast.makeText(SettingsActivity.this, "Strict Mode: " + (isChecked ? "Enabled" : "Disabled"), Toast.LENGTH_SHORT).show();
            }
        });

        // Initialize About button
        TextView aboutButton = findViewById(R.id.about_button);
        aboutButton.setOnClickListener(v -> {
            Intent intent = new Intent(SettingsActivity.this, About.class);
            startActivity(intent);
        });
    }
}