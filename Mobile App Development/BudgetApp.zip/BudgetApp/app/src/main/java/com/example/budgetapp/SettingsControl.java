package com.example.budgetapp;

import android.content.Context;
import android.content.SharedPreferences;

public class SettingsControl {
    private static final String PREFS_NAME = "BudgetPrefs";
    private static final String KEY_CURRENCY = "currency";
    private static final String KEY_STRICT_MODE = "strictMode";
    private static final String KEY_AUTO_ROUND = "autoRound";
    private static final String KEY_TOTAL_BUDGET = "totalBudget";
    private static final String KEY_REMAINING_BUDGET = "remainingBudget";
    private static final String KEY_EXPENSES_LIST = "expensesList";

    private SharedPreferences sharedPreferences;

    public SettingsControl(Context context) {
        sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    // Currency
    public String getCurrencySymbol() {
        return sharedPreferences.getString(KEY_CURRENCY, "₱ PHP").split(" ")[0];
    }

    public void setCurrency(String currency) {
        sharedPreferences.edit().putString(KEY_CURRENCY, currency).apply();
    }

    public String getCurrency() {
        return sharedPreferences.getString(KEY_CURRENCY, "₱ PHP");
    }


    // Strict Mode
    public boolean isStrictModeEnabled() {
        return sharedPreferences.getBoolean(KEY_STRICT_MODE, true);
    }

    public void setStrictMode(boolean isEnabled) {
        sharedPreferences.edit().putBoolean(KEY_STRICT_MODE, isEnabled).apply();
    }

    // Auto-Round
    public boolean isAutoRoundEnabled() {
        return sharedPreferences.getBoolean(KEY_AUTO_ROUND, false);
    }

    public void setAutoRound(boolean isEnabled) {
        sharedPreferences.edit().putBoolean(KEY_AUTO_ROUND, isEnabled).apply();
    }

    // Budget
    public float getTotalBudget() {
        return sharedPreferences.getFloat(KEY_TOTAL_BUDGET, 0);
    }

    public void setTotalBudget(float budget) {
        sharedPreferences.edit().putFloat(KEY_TOTAL_BUDGET, budget).apply();
    }

    public float getRemainingBudget() {
        return sharedPreferences.getFloat(KEY_REMAINING_BUDGET, getTotalBudget());
    }

    public void setRemainingBudget(float budget) {
        sharedPreferences.edit().putFloat(KEY_REMAINING_BUDGET, budget).apply();
    }

    // Expenses List
    public String getExpensesList() {
        return sharedPreferences.getString(KEY_EXPENSES_LIST, "");
    }

    public void setExpensesList(String expenses) {
        sharedPreferences.edit().putString(KEY_EXPENSES_LIST, expenses).apply();
    }
}
