package com.example.budgetapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    // Database details
    public static final String DATABASE_NAME = "budget.db";
    public static final int DATABASE_VERSION = 1;

    // Table name
    public static final String TABLE_EXPENSES = "tblExpenses";

    // Columns
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_AMOUNT = "amount";  // Original budget
    public static final String COLUMN_EXPENSES = "expenses";  // Total expenses
    public static final String COLUMN_TOTAL = "total";  // Remaining budget (Amount - Expenses)
    public static final String COLUMN_DATE = "date";  // Date

    private Context mContext;

    // Constructor
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.mContext = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create expenses table with a new 'total' column
        String createTable = "CREATE TABLE " + TABLE_EXPENSES + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_AMOUNT + " FLOAT, " +
                COLUMN_EXPENSES + " FLOAT, " +
                COLUMN_TOTAL + " FLOAT, " +  // This stores the calculated total (amount - expenses)
                COLUMN_DATE + " TEXT)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EXPENSES);
        onCreate(db);
    }

    // Insert an expense into the database (with total calculated)
    public boolean addExpense(float expenseAmount, String date) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Get the previous remaining budget
        float previousRemaining = getCurrentRemainingBudget();
        if (previousRemaining == 0) {
            // First expense - use the total budget from settings
            previousRemaining = new SettingsControl(mContext).getTotalBudget();
        }

        // Calculate new remaining
        float newRemaining = previousRemaining - expenseAmount;

        ContentValues values = new ContentValues();
        values.put(COLUMN_AMOUNT, previousRemaining); // Store previous remaining as "amount"
        values.put(COLUMN_EXPENSES, expenseAmount);
        values.put(COLUMN_TOTAL, newRemaining);  // Store new remaining
        values.put(COLUMN_DATE, date);

        long result = db.insert(TABLE_EXPENSES, null, values);
        db.close();
        return result != -1;
    }

    public float getCurrentRemainingBudget() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COLUMN_TOTAL + " FROM " + TABLE_EXPENSES +
                " ORDER BY " + COLUMN_ID + " DESC LIMIT 1", null);

        float remaining = 0;
        if (cursor.moveToFirst()) {
            remaining = cursor.getFloat(0);
        }
        cursor.close();
        return remaining;
    }

    public void clearAllExpenses() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE_EXPENSES);
        db.close();
    }

    public Cursor getAllRecords() {
        SQLiteDatabase db = this.getReadableDatabase();

        // Query to retrieve all records, including the calculated total column
        return db.rawQuery("SELECT " + COLUMN_ID + ", " +
                COLUMN_AMOUNT + ", " +
                COLUMN_EXPENSES + ", " +
                COLUMN_TOTAL + ", " +  // Now selecting the total stored in the database
                COLUMN_DATE +
                " FROM " + TABLE_EXPENSES, null);
    }
    // Add this method to your DatabaseHelper class
    public boolean updateRecord(int id, float amount, float expenses, String date) {
        float total = amount - expenses;  // Recalculate the total

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_AMOUNT, amount);
        values.put(COLUMN_EXPENSES, expenses);
        values.put(COLUMN_TOTAL, total);
        values.put(COLUMN_DATE, date);

        int rowsAffected = db.update(TABLE_EXPENSES, values, COLUMN_ID + " = ?",
                new String[]{String.valueOf(id)});
        db.close();

        return rowsAffected > 0;
    }
    public boolean deleteRecord(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsAffected = db.delete(TABLE_EXPENSES, COLUMN_ID + " = ?",
                new String[]{String.valueOf(id)});
        db.close();
        return rowsAffected > 0;
    }

}
