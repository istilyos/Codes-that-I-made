package com.example.budgetapp;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class AllRecords extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private CustomCursorAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_records);

        // Set up toolbar and back button
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        dbHelper = new DatabaseHelper(this);
        refreshListView();

        // Set item click listener
        ListView lvAllRecords = findViewById(R.id.lvAllRecords);
        lvAllRecords.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Cursor cursor = (Cursor) parent.getItemAtPosition(position);

                int recordId = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID));
                float amount = cursor.getFloat(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_AMOUNT));
                float expenses = cursor.getFloat(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EXPENSES));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DATE));

                Intent intent = new Intent(AllRecords.this, EditRecord.class);
                intent.putExtra("recordId", recordId);
                intent.putExtra("expenses", expenses);
                intent.putExtra("amount", amount);

                intent.putExtra("date", date);
                startActivityForResult (intent, 1);
            }
        });
    }

    private void refreshListView() {
        Cursor cursor = dbHelper.getAllRecords();

        SettingsControl settings = new SettingsControl(this);
        boolean isAutoRoundEnabled = settings.isAutoRoundEnabled();
        String currencySymbol = settings.getCurrencySymbol();

        ListView lvAllRecords = findViewById(R.id.lvAllRecords);
        if (adapter == null) {
            adapter = new CustomCursorAdapter(this, cursor, isAutoRoundEnabled, currencySymbol);
            lvAllRecords.setAdapter(adapter);
        } else {
            adapter.changeCursor(cursor);
            adapter.notifyDataSetChanged();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_all_records, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_reset_expenses) {
            resetExpenses();
            return true;
        } else if (id == R.id.action_settings) {
            Intent intent = new Intent(AllRecords.this, SettingsActivity.class);
            startActivity(intent);
            return true;
        } else if (id == R.id.action_about) {
            Intent intent = new Intent(AllRecords.this, About.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Handle "Reset Expenses" action with confirmation dialog
    private void resetExpenses() {
        new AlertDialog.Builder(this)
                .setTitle("Confirm Reset")
                .setMessage("Are you sure you want to reset all expenses? This action cannot be undone.")
                .setPositiveButton("Reset", (dialog, which) -> {
                    // Clear the expenses in the database
                    dbHelper.clearAllExpenses();

                    // Reset remaining budget to total budget
                    SettingsControl settings = new SettingsControl(this);
                    settings.setRemainingBudget(settings.getTotalBudget());

                    // Refresh list view
                    refreshListView();

                    Toast.makeText(this, "Expenses Reset!", Toast.LENGTH_SHORT).show();

                    // Notify MainActivity of changes
                    setResult(RESULT_OK);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            // Refresh the list if any changes were made
            refreshListView();

            // Set result to notify MainActivity
            setResult(RESULT_OK);
        }
    }
}