package com.example.budgetapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import java.util.ArrayList;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private EditText etBudget, etExpense;
    private Button btnSetBudget, btnAddExpense;
    private TextView tvRemainingBudget;
    private ListView lvExpenses;
    private ArrayList<String> expensesList;
    private ExpensesAdapter expensesAdapter;

    private SettingsControl settingsControl;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set up toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Initialize SettingsControl
        settingsControl = new SettingsControl(this);
        databaseHelper = new DatabaseHelper(this);

        // Initialize views
        etBudget = findViewById(R.id.et_budget);
        etExpense = findViewById(R.id.et_expense);
        btnSetBudget = findViewById(R.id.btn_set_budget);
        btnAddExpense = findViewById(R.id.btn_add_expense);
        tvRemainingBudget = findViewById(R.id.tv_remaining_budget);
        lvExpenses = findViewById(R.id.lv_expenses);

        // Initialize expenses list
        expensesList = new ArrayList<>();

        // Load data
        loadData();

        // Set up adapter
        expensesAdapter = new ExpensesAdapter(this, expensesList);
        lvExpenses.setAdapter(expensesAdapter);

        // TextWatcher to enable buttons only when input is provided
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                btnSetBudget.setEnabled(!etBudget.getText().toString().isEmpty());
                btnAddExpense.setEnabled(!etExpense.getText().toString().isEmpty());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        };

        etBudget.addTextChangedListener(textWatcher);
        etExpense.addTextChangedListener(textWatcher);

        Button btnViewRecords = findViewById(R.id.btn_view_records);
        btnViewRecords.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AllRecords.class);
            startActivityForResult(intent, 2);
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_bar, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Helper method to show toasts on the main thread
    private void showToast(final String message) {
        runOnUiThread(() -> {
            Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
        });
    }

    // Handle "Set Budget" button click with confirmation dialog
    public void setBudget(View view) {
        String budgetInput = etBudget.getText().toString();
        if (!budgetInput.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("Confirm Budget")
                    .setMessage("Are you sure you want to set the budget to " +
                            settingsControl.getCurrencySymbol() + budgetInput + "?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        float totalBudget = Float.parseFloat(budgetInput);
                        settingsControl.setTotalBudget(totalBudget);
                        settingsControl.setRemainingBudget(totalBudget);
                        updateRemainingBudget();
                        etBudget.setText("");
                        showToast("Budget Set!");
                    })
                    .setNegativeButton("No", null)
                    .show();
        }
    }

    // Handle "Add Expense" button click
    public void addExpense(View view) {
        String expenseInput = etExpense.getText().toString();

        if (!expenseInput.isEmpty()) {
            float expenseAmount = Float.parseFloat(expenseInput);

            // Apply auto-rounding if enabled
            if (settingsControl.isAutoRoundEnabled()) {
                expenseAmount = Math.round(expenseAmount);
            }

            // Check if there are any records in the database
            float currentRemaining;
            boolean hasRecords = databaseHelper.hasAnyRecords();

            if (hasRecords) {
                currentRemaining = databaseHelper.getCurrentRemainingBudget();
            } else {
                currentRemaining = settingsControl.getTotalBudget();
            }

            if (settingsControl.isStrictModeEnabled() && expenseAmount > currentRemaining) {
                showToast("Not enough budget! (Strict Mode Enabled)");
                return;
            }

            // Add to database - now only needs expenseAmount and date
            if (databaseHelper.addExpense(expenseAmount, getCurrentDate())) {
                // Update UI
                expensesList.add(settingsControl.getCurrencySymbol() + expenseAmount);
                expensesAdapter.notifyDataSetChanged();
                updateRemainingBudget();
                etExpense.setText("");
                showToast("Expense Added!");
            }
        }
    }

    private void updateRemainingBudget() {
        float remaining;
        boolean hasRecords = databaseHelper.hasAnyRecords();

        if (hasRecords) {
            remaining = databaseHelper.getCurrentRemainingBudget();
        } else {
            remaining = settingsControl.getTotalBudget();
        }

        tvRemainingBudget.setText("Remaining Budget: " +
                settingsControl.getCurrencySymbol() +
                remaining);
    }

    // Method to get the current date in "YYYY-MM-DD" format
    private String getCurrentDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        return sdf.format(new Date());
    }

    private void saveData() {
        // Save expenses without currency symbol
        StringBuilder expensesString = new StringBuilder();
        for (String expense : expensesList) {
            expensesString.append(expense.substring(1)).append(",");
        }
        settingsControl.setExpensesList(expensesString.toString());
    }

    private void loadData() {
        expensesList.clear();
        String savedExpenses = settingsControl.getExpensesList();
        String currencySymbol = settingsControl.getCurrencySymbol();

        if (!savedExpenses.isEmpty()) {
            String[] expensesArray = savedExpenses.split(",");
            for (String expense : expensesArray) {
                if (!expense.isEmpty()) expensesList.add(currencySymbol + expense);
            }
        }

        updateRemainingBudget();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateRemainingBudget();

        for (int i = 0; i < expensesList.size(); i++) {
            String oldExpense = expensesList.get(i);
            String updatedExpense = settingsControl.getCurrencySymbol() + oldExpense.substring(1);
            expensesList.set(i, updatedExpense);
        }

        expensesAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2 && resultCode == RESULT_OK) {
            // Refresh data when returning from AllRecords
            loadData();
            expensesAdapter.notifyDataSetChanged();
            updateRemainingBudget();
        }
    }
}