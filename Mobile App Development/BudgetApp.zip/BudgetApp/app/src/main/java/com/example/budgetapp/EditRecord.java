package com.example.budgetapp;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.google.android.material.textfield.TextInputLayout;
import java.util.Calendar;

public class EditRecord extends AppCompatActivity {
    private EditText etAmount, etExpenses, etDate;
    private TextInputLayout tilDate;
    private int recordId;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_record);

        // Set up toolbar and back button
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        dbHelper = new DatabaseHelper(this);

        // Initialize views
        etAmount = findViewById(R.id.etAmount);
        etExpenses = findViewById(R.id.etExpenses);
        etDate = findViewById(R.id.etDate);
        tilDate = findViewById(R.id.tilDate);
        Button btnSave = findViewById(R.id.btnSave);
        Button btnDelete = findViewById(R.id.btnDelete);

        // Get data from intent
        Intent intent = getIntent();
        if (intent != null) {
            recordId = intent.getIntExtra("recordId", -1);
            float amount = intent.getFloatExtra("amount", 0);
            float expenses = intent.getFloatExtra("expenses", 0);
            String date = intent.getStringExtra("date");

            // Populate the fields
            etAmount.setText(String.valueOf(amount));
            etExpenses.setText(String.valueOf(expenses));
            etDate.setText(date);

            Toast.makeText(this, "Editing record #" + recordId, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "No record data found", Toast.LENGTH_SHORT).show();
            finish();
        }

        // Set up date picker for date field and calendar icon
        etDate.setOnClickListener(v -> showDatePickerDialog());
        tilDate.setEndIconOnClickListener(v -> showDatePickerDialog());

        // Set up save button with confirmation
        btnSave.setOnClickListener(v -> {
            try {
                // Validate inputs first
                float amount = Float.parseFloat(etAmount.getText().toString());
                float expenses = Float.parseFloat(etExpenses.getText().toString());
                String date = etDate.getText().toString();

                if (date.isEmpty()) {
                    Toast.makeText(this, "Date cannot be empty", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Show confirmation dialog before saving
                showUpdateConfirmationDialog(amount, expenses, date);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Please enter valid numbers for amount and expenses", Toast.LENGTH_SHORT).show();
            }
        });

        // Set up delete button with confirmation dialog
        btnDelete.setOnClickListener(v -> showDeleteConfirmationDialog());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void showDatePickerDialog() {
        // Get current date or existing date from etDate
        Calendar calendar = Calendar.getInstance();
        String currentDate = etDate.getText().toString();
        if (!currentDate.isEmpty()) {
            try {
                String[] dateParts = currentDate.split("-");
                int year = Integer.parseInt(dateParts[0]);
                int month = Integer.parseInt(dateParts[1]) - 1; // Month is 0-based in Calendar
                int day = Integer.parseInt(dateParts[2]);
                calendar.set(year, month, day);
            } catch (Exception e) {
                // Fallback to current date if parsing fails
            }
        }

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        // Show DatePickerDialog
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    // Format the selected date as YYYY-MM-DD
                    String formattedDate = String.format("%04d-%02d-%02d", selectedYear, selectedMonth + 1, selectedDay);
                    etDate.setText(formattedDate);
                },
                year,
                month,
                day
        );
        datePickerDialog.show();
    }

    private void showUpdateConfirmationDialog(float amount, float expenses, String date) {
        new AlertDialog.Builder(this)
                .setTitle("Confirm Update")
                .setMessage("Are you sure you want to update this record?\n\n" +
                        "Amount: " + amount + "\n" +
                        "Expenses: " + expenses + "\n" +
                        "Date: " + date)
                .setPositiveButton("Update", (dialog, which) -> {
                    Toast.makeText(this, "Updating record...", Toast.LENGTH_SHORT).show();
                    updateRecord(amount, expenses, date);
                })
                .setNegativeButton("Cancel", (dialog, which) -> {
                    Toast.makeText(this, "Update cancelled", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                })
                .setIcon(android.R.drawable.ic_dialog_info)
                .show();
    }

    private void updateRecord(float amount, float expenses, String date) {
        boolean success = dbHelper.updateRecord(recordId, amount, expenses, date);

        if (success) {
            Toast.makeText(this, "Record updated successfully", Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
            finish();
        } else {
            Toast.makeText(this, "Failed to update record", Toast.LENGTH_SHORT).show();
        }
    }

    private void showDeleteConfirmationDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Confirm Deletion")
                .setMessage("Are you sure you want to permanently delete this record?\n\nThis action cannot be undone.")
                .setPositiveButton("Delete", (dialog, which) -> {
                    Toast.makeText(this, "Deleting record...", Toast.LENGTH_SHORT).show();
                    deleteRecord();
                })
                .setNegativeButton("Cancel", (dialog, which) -> {
                    Toast.makeText(this, "Deletion cancelled", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                })
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    private void deleteRecord() {
        boolean success = dbHelper.deleteRecord(recordId);

        if (success) {
            Toast.makeText(this, "Record deleted successfully", Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
            finish();
        } else {
            Toast.makeText(this, "Failed to delete record", Toast.LENGTH_SHORT).show();
        }
    }
}